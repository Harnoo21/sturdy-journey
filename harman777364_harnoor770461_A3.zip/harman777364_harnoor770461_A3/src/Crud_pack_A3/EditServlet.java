package Crud_pack_A3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EditServlet() {
        super();}
        
        protected void doGet(HttpServletRequest request, HttpServletResponse response)   
                throws ServletException, IOException {  
             response.setContentType("text/html");  
             PrintWriter out=response.getWriter();  
             out.println("<h1>Update Student Record</h1>");  
             String itemId =request.getParameter("id");  
             String id=itemId;  
               
             Store e=StoreDAO.getStorebyId(id);  
             
             out.print("<!DOCTYPE html>");
             out.print(" <html>");
             out.print(" <head>");
             out.print(" <meta charset=\"ISO-8859-1\">");
             out.print(" <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
             out.print("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>");
             out.print("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");
             out.print(" <title>Insert title here</title>");
             out.print("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"); 
             out.print("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/mystyles.css\">");     
             out.print("<body>");
             out.print("<div class=\"imgcontainer\">");         
             out.print("<img src=\"images/iconPersonOffice.jpg\" alt=\"Lambton College\" class=\"logo\">");
             out.print("  </div>");
             out.print("<form action='UpdateServlet' method='post'>"); 
             out.print(" <div class=\"container\">");
             out.print("<div class=\"container\">");
             out.print("<table class=\"table-success\">");  
             out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getItemId()+"'/></td></tr>");  
             out.print("<tr><td>Item Name:</td><td><input type='text' name='iname' value='"+e.getItemName()+"'/></td></tr>");  
             out.print("<tr><td>Department:</td><td><input type='text' name='iname' value='"+e.getDepartment()+"'/>  </td></tr>");  
             out.print("<tr><td>Item Type:</td><td><input type='text' name='itype' value='"+e.getItemType()+"'/></td></tr>");  
             out.print("<tr><td>Item Price</td><td><input type='text' name='iprice' value='"+e.getItemPrice()+"'/></td></tr>"); 
             out.print("<tr><td colspan='2'><input type='submit' value='Save Changes '/></td><!-- ");  
             out.print("--><td colspan='2'><!-- --><div id=\"stripe\"><input type='button' value='HOME PAGE ' onclick=\"window.location.href = 'http://localhost:8082//harman777364_harnoor770461_A3/index.html';\"/></td></tr>");  
             
             out.print("</div></table>");  
             out.print(" </div>");
             out.print(" </form>");
             out.print("</body>");
             out.print("</html>");
                 
             out.close();  
         }  

}
    	