package Crud_pack_A3;

public class Store {
	
	private String ItemName,department,ItemType;
	private Double itemId,ItemPrice,final_price;

	public String getItemName() {
		return ItemName;
	}

	public void setItemName(String itemName) {
		ItemName = itemName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getItemType() {
		return ItemType;
	}

	public void setItemType(String itemType) {
		ItemType = itemType;
	}

	public Double getItemId() {
		return itemId;
	}

	public void setItemId(Double itemId) {
		this.itemId = itemId;
	}

	public Double getItemPrice() {
		return ItemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		ItemPrice = itemPrice;
	}

	public Double getFinal_price() {
		return final_price;
	}

	public void setFinal_price(Double final_price) {
		this.final_price = final_price;
	}

	public Store() {
		
	}
	
	
	

}
