package Crud_pack_A3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class StoreDAO {


	public StoreDAO(){
		
	}
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "H@rm@n2001");
			System.out.print("in jdbc" + con);

		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
		
	}
	
	public static int save(Store e) {
		int status = 0;

		try {
			Connection con = getConnection();
			System.out.println("After Connection Done");
			PreparedStatement ps = con.prepareStatement("insert into items_java(itemId,ItemName,department,ItemType,ItemPrice,final_price)values(?,?,?,?,?,?)");

			System.out.println("After Insert Stattement");

			ps.setDouble(1,e.getItemId() );
			ps.setString(2,e.getItemName());
			ps.setString(3,e.getDepartment());
			ps.setString(4,e.getItemType() );
			ps.setDouble(5,e.getItemPrice());
			ps.setDouble(6,e.getFinal_price());

			status=ps.executeUpdate();
			
			con.close();
			
			
			}catch(Exception ex) {ex.printStackTrace();};
		

		return status;
	}

	public static Store getStudentByName(String name) {
		Store s = new Store();

		try {
			Connection con =  StoreDAO.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from items_java where ItemName =?");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				s.setItemId(rs.getDouble(1));
				s.setItemName(rs.getString(2));
				s.setDepartment(rs.getString(3));
				s.setItemType(rs.getString(4));
				s.setItemPrice(rs.getDouble(5));
				s.setFinal_price(rs.getDouble(6));

			}
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return s;
	}
	
	public static Store getStorebyId(String id) {
		Store e=new Store();  
        System.out.println("\n in getStoreById() method where id parameter "+id);
        try{  
            Connection con=StoreDAO.getConnection();  
            PreparedStatement ps=con.prepareStatement("select itemId,ItemName,department,ItemType,ItemPrice,final_price from items_java where itemId=?");  
           
            ps.setString(1,id);  
            ResultSet rs=ps.executeQuery();  
            
            if(rs.next()){  
            	e.setItemId(rs.getDouble(1));
				e.setItemName(rs.getString(2));
				e.setDepartment(rs.getString(3));
				e.setItemType(rs.getString(4));
				e.setItemPrice(rs.getDouble(5));
				e.setFinal_price(rs.getDouble(6));
                System.out.print("\n Name is "+e.getItemName());
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          System.out.println("\n in getStoreById() method where name is "+e.getItemName());
        return e;  
		
	
	}  
	
	
	public static List<Store> getAllStore(){  
        List<Store> list=new ArrayList<Store>();  
          
        try{  
            Connection con=StoreDAO.getConnection(); 
            PreparedStatement ps=con.prepareStatement("select itemId,ItemName,department,ItemType,ItemPrice,final_price from items_java");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
            	Store s=new Store();  
            	s.setItemId(rs.getDouble(1));
				s.setItemName(rs.getString(2));
				s.setDepartment(rs.getString(3));
				s.setItemType(rs.getString(4));
				s.setItemPrice(rs.getDouble(5));
				s.setFinal_price(rs.getDouble(6));
                list.add(s);
                    
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();
        }  
          
        return list;
        
	}

	public static int update(Store e) {
		int status=0;  
        try{  
            Connection con=StoreDAO.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
            		"update items_java set ItemName =?,department=?,ItemType=?,ItemPrice=?,final_price=?+?+? where itemId=?");  
             
            ps.setString(1,e.getItemName());  
            ps.setString(2,e.getDepartment());  
            ps.setString(3,e.getItemType());  
            ps.setDouble(4,e.getItemPrice()); 
            ps.setString(5,e.getDepartment());  
            ps.setString(6,e.getItemType());  
            ps.setDouble(7,e.getItemPrice());  
            ps.setDouble(8,e.getItemId());  
            
            System.out.println(ps.getUpdateCount());
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }
	// ############################# >> Deleting Row IN Table  
	
			 public static Double delete(Double tid){  
			        Double status=(double) 0;  
			        try{  
			            Connection con=StoreDAO.getConnection();  
			            PreparedStatement ps=con.prepareStatement("delete from items_java  where itemId =?");  
			            ps.setDouble(1,tid);  
			            status=(double) ps.executeUpdate();  
			              
			            con.close();  
			            System.out.println(status);
						
			        }catch(Exception e){e.printStackTrace();}  
			          
			        return status;  

		
			 }
}			 
			 
