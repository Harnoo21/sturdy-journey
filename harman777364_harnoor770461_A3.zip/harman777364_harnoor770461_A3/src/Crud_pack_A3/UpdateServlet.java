package Crud_pack_A3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
	    PrintWriter out=response.getWriter();  
	      
	    Double itemId = Double.parseDouble(request.getParameter("id"));
		String ItemName= request.getParameter("iname");
		String department= request.getParameter("dpt");
		String ItemType= request.getParameter("itype");
		Double ItemPrice= Double.parseDouble(request.getParameter("iprice"));
		
	    Store e=new Store();  
	    e.setItemId(itemId);
	    e.setItemName(ItemName);
	    e.setDepartment(department);
	    e.setItemType(ItemType);
	    e.setItemPrice(ItemPrice);
	      
	
	    int status=StoreDAO.update(e);  
	    
	    if(status>0){
	    	
	        response.sendRedirect("ViewServlet");  
	    }else{  
	        out.println("opps! Something went wrong." );  
	    }  
	    System.out.println("status = "+ status ); //debug statement to know the value of status
	    out.close();  
		}
	

}
