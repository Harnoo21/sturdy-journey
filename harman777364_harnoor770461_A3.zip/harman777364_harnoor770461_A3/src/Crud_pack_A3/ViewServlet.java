package Crud_pack_A3;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ViewServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html"); 
	     
	     PrintWriter out=response.getWriter();  
	     
	     out.println("<a href='index.html'>Add New item</a>");  
	     out.println("<h1>Student Database</h1>");  
	       
	     List<Store> list=StoreDAO.getAllStore();  
	     out.print(" <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
	     out.print("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>");
	     out.print("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");  
	     out.print("<table class=\"table table-striped\">"); 
	     //out.print("<table border='1' width='100%'");  
	     out.print("<tr><th>Item Id</th><th>Item Name</th><th>Department</th><th>Item Type</th><th>Item Price</th>  <th>Edit</th><th>Delete</th></tr>");  
	    for(Store e:list){  
	      out.print("<tr><td>"+e.getItemId()+"</td><td>"+e.getItemName()+"</td><td>"+e.getDepartment()+"</td>  <td>"+e.getItemType()+"</td><td>"+e.getItemPrice()+"</td><td><a href='EditServlet?id="+e.getItemId()+"'>edit</a></td>  <td><a href='DeleteServlet?id="+e.getItemId()+"'>delete</a></td></tr>");  
	     } 
	     out.print("</table>");  
	       
	     out.close();  
	}



}
