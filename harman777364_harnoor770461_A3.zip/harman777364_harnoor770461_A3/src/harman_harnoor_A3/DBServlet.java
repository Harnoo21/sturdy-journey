package harman_harnoor_A3;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DBServlet")
public class DBServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DBServlet() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Double itemId = Double.parseDouble(request.getParameter("id"));
		String ItemName= request.getParameter("iname");
		String department= request.getParameter("dpt");
		String ItemType= request.getParameter("itype");
		Double ItemPrice= Double.parseDouble(request.getParameter("iprice"));
		
		
		// calculating price with tax
		
		Double final_price = ItemPrice +ItemPrice*0.13;
		
		out.println("<h1>Price of the " + ItemName + " in system is " + final_price + "</h1>");
		
		try {
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("insert into items_java(itemId,ItemName,department,ItemType,ItemPrice,final_price)values(?,?,?,?,?,?)");
		ps.setDouble(1, itemId );
		ps.setString(2, ItemName);
		ps.setString(3, department);
		ps.setString(4,ItemType );
		ps.setDouble(5, ItemPrice);
		ps.setDouble(6,final_price);
		
		int status=ps.executeUpdate();
		
		con.close();
		
		
		}catch(Exception e) {e.printStackTrace();};
	}
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "H@rm@n2001");
			System.out.print("in jdbc" + con);

		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}
}
