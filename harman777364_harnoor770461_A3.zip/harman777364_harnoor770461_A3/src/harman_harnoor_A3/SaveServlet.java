package harman_harnoor_A3;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final double final_price = 0;
       
    public SaveServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String itemId = request.getParameter("id");
		String ItemName= request.getParameter("iname");
		String department= request.getParameter("dpt");
		String ItemType= request.getParameter("itype");
		Double ItemPrice= Double.parseDouble(request.getParameter("iprice"));
		
		
		// calculating price with tax
		
		Double final_price = ItemPrice +ItemPrice*0.13;
		
		out.println("<h1>Price of the " + ItemName + " in system is " + final_price + "</h1>");
	}

}
